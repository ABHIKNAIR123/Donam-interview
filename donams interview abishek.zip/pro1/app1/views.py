from django.shortcuts import render
from app1.models import User
from django.http import HttpResponse


def home(request):
    return render(request, 'index.html')

def login(request):
    if request.method == "POST":
        username:request.POST['username']
        password:request.POST['password']
        data = User(username=username, password=password)
        data.save()
    return render(request, 'login.html')


def register(request):
    if request.method == "POST":
        username : request.POST['username']
        firstname : request.POST['firstname']
        lastname : request.POST['lastname']
        phone : request.POST['phone']
        email : request.POST['email']
        password : request.POST['password']
        data2 = User(username=username, firstname=firstname,lastname=lastname,phone=phone,email=email,password=password)
        data2.save()
    return render(request, 'register.html')

def success(request):
    return HttpResponse('Success')
# Create your views here.
