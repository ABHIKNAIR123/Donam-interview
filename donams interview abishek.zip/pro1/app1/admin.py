from django.contrib import admin
from app1.models import User

admin.site.register(User)
# Register your models here.
